import React from 'react';
import styles from './Step6StrokeResults.module.css';

export default function Step6StrokeResults({
  participants,  // [{ id, group, nickname, handicap, score, room }, …]
  roomCount,     // 총 방 개수
  onPrev,        // ← 이전
  onNext         // 다음 →
}) {
  const maxRows = 4;

  // 1) 방별로 참가자 묶기
  const byRoom = Array.from({ length: roomCount }, () => []);
  participants.forEach(p => {
    if (p.room != null) {
      byRoom[p.room - 1].push(p);
    }
  });

  // 2) 방배정표용: 4행 × 방Count
  const allocationRows = Array.from({ length: maxRows }, (_, rowIdx) =>
    byRoom.map(roomArr =>
      roomArr.find(p => p.group === rowIdx + 1)
      || { nickname: '', handicap: '' }
    )
  );

  // 3) 최종결과표용 계산
  const resultByRoom = byRoom.map(roomArr => {
    // group 순으로 채운 4명 배열
    const filled = Array.from({ length: maxRows }, (_, i) =>
      roomArr.find(p => p.group === i + 1)
      || { nickname:'', handicap:0, score:0 }
    );
    // 최고 스코어 인덱스
    let maxIdx = 0, maxVal = -Infinity;
    filled.forEach((p,i) => {
      const sc = p.score ?? 0;
      if (sc > maxVal) {
        maxVal = sc; maxIdx = i;
      }
    });
    // 반땅·결과 계산
    let sumScore = 0, sumBanddang = 0, sumResult = 0;
    const detail = filled.map((p,i) => {
      const sc = p.score ?? 0;
      const banddang = (i === maxIdx) ? Math.floor(sc/2) : sc;
      const result = banddang - (p.handicap ?? 0);
      sumScore += sc;
      sumBanddang += banddang;
      sumResult += result;
      return { ...p, score: sc, banddang, result };
    });
    return { detail, sumScore, sumBanddang, sumResult };
  });

  // 4) 방별 순위
  const ranks = resultByRoom
    .map((r,i) => ({ roomIdx:i, total:r.sumResult }))
    .sort((a,b) => a.total - b.total)
    .map((r,idx) => ({ roomIdx:r.roomIdx, rank: idx+1 }));
  const rankMap = Object.fromEntries(ranks.map(r => [r.roomIdx, r.rank]));

  // 방 번호 리스트
  const rooms = Array.from({ length: roomCount }, (_, i) => i);

  return (
    <div className={styles.step}>
      {/* 1차 헤더 (1~5단계와 동일 톤앤매너) */}
      <div className={styles.stepHeader}>
        <h3>6. 스트로크 결과표</h3>
      </div>

      {/* 방배정표 */}
      <div className={styles.tableContainer}>
        <h4 className={styles.tableTitle}>🏠 방배정표</h4>
        <table className={styles.table}>
          <thead>
            <tr>
              {rooms.map(r => (
                <th key={r} colSpan={2} className={styles.header}>
                  {r+1}번방
                </th>
              ))}
            </tr>
            <tr>
              {rooms.map(r => (
                <React.Fragment key={r}>
                  <th className={styles.header}>닉네임</th>
                  <th className={styles.header}>G핸디</th>
                </React.Fragment>
              ))}
            </tr>
          </thead>
          <tbody>
            {allocationRows.map((row, ri) => (
              <tr key={ri}>
                {row.map((cell, ci) => (
                  <React.Fragment key={ci}>
                    <td className={styles.cell}>{cell.nickname}</td>
                    <td className={styles.cell}>{cell.handicap}</td>
                  </React.Fragment>
                ))}
              </tr>
            ))}
          </tbody>
          <tfoot>
            <tr>
              {resultByRoom.map((_, ci) => {
                // 합계는 handicap 합계가 아니라 handicap 컬럼 아래에 sum of handicap?
                // 방배정표에서는 G핸디 합
                const sumGhandi = byRoom[ci]
                  .reduce((s,p)=> s + (Number(p.handicap)||0), 0);
                return (
                  <React.Fragment key={ci}>
                    <td className={styles.footerLabel}>합계</td>
                    <td className={styles.footerValue}>{sumGhandi}</td>
                  </React.Fragment>
                );
              })}
            </tr>
          </tfoot>
        </table>
      </div>

      {/* 최종결과표 */}
      <div className={styles.tableContainer}>
        <h4 className={styles.tableTitle}>📊 최종결과표</h4>
        <table className={styles.table}>
          <thead>
            <tr>
              {rooms.map(r => (
                <th key={r} colSpan={4} className={styles.header}>
                  {r+1}번방
                </th>
              ))}
            </tr>
            <tr>
              {rooms.map(r => (
                <React.Fragment key={r}>
                  <th className={styles.header}>닉네임</th>
                  <th className={styles.header}>점수</th>
                  <th className={styles.header}>반땅</th>
                  <th className={styles.header}>결과</th>
                </React.Fragment>
              ))}
            </tr>
          </thead>
          <tbody>
            {Array.from({ length: maxRows }).map((_, ri) => (
              <tr key={ri}>
                {resultByRoom.map((room, ci) => {
                  const p = room.detail[ri];
                  return (
                    <React.Fragment key={ci}>
                      <td className={styles.cell}>{p.nickname}</td>
                      <td className={styles.cell}>{p.score}</td>
                      <td className={styles.cell} style={{color:'blue'}}>
                        {p.bandang}
                      </td>
                      <td className={styles.cell} style={{color:'red'}}>
                        {p.result}
                      </td>
                    </React.Fragment>
                  );
                })}
              </tr>
            ))}
          </tbody>
          <tfoot>
            {/* 합계 행 */}
            <tr>
              {resultByRoom.map((room, ci) => (
                <React.Fragment key={ci}>
                  <td className={styles.footerLabel}>합계</td>
                  <td className={styles.footerValue}>{room.sumScore}</td>
                  <td className={styles.footerBanddang}>{room.sumBanddang}</td>
                  <td className={styles.footerResult}>{room.sumResult}</td>
                </React.Fragment>
              ))}
            </tr>
            {/* 순위 행 */}
            <tr>
              {rooms.map(r => (
                <React.Fragment key={r}>
                  <td colSpan={3} className={styles.footerBlank}></td>
                  <td className={styles.footerRank}>
                    {rankMap[r]}등
                  </td>
                </React.Fragment>
              ))}
            </tr>
          </tfoot>
        </table>
      </div>

      {/* 하단 버튼 */}
      <div className={styles.stepFooter}>
        <button onClick={onPrev}>← 이전</button>
        <button onClick={onNext}>다음 →</button>
      </div>
    </div>
  );
}
